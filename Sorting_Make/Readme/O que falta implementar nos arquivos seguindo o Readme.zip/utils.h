#ifndef UTILS_H
#define UTILS_H

void fill_random(int* v, int n, int max);
void print_array(int* v, int n);
int is_sorted(int* v, int n);

#endif
