/*
 * provap1-q2-manus.c
 *
 * Solução para a Questão 2 da Prova P1 - 2016-1 (FEN06-04049 - Laboratório de Programação I)
 *
 * Objetivo: Implementar uma criptografia por transposição contínua com incremento
 *           variável e contagem de ocorrências de caracteres.
 *
 * Autor: Manus
 *
 * Observações:
 * - O código segue o modelo de modularidade e estilo de programação em C
 *   visto nos exercícios do repositório LabProg_UERJ.
 * - A contagem de transposição é contínua (não reinicia por linha).
 * - A contagem de ocorrências de cada letra (A-Z, a-z) é reiniciada ao atingir 26.
 * - O programa deve processar múltiplas linhas e parar com linha vazia (apenas \n).
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define MAXLINHA 1000
#define ALFABETO_TAM 26

// Variáveis globais para manter o estado contínuo da criptografia
// Conforme as observações da prova, variáveis globais são permitidas,
// mas descontam 1 ponto. Para este exercício, vamos usá-las para
// manter o estado (contagem de ocorrências) entre as linhas.

// Contagem de vezes que cada letra (A-Z ou a-z) apareceu.
// O índice 0 é para 'A'/'a', 1 para 'B'/'b', ..., 25 para 'Z'/'z'.
static int contagem_ocorrencias[ALFABETO_TAM] = {0};

/*
 * lelinha: lê uma linha do teclado, armazena em 's' e retorna o tamanho.
 * Retorna 1 se a linha lida não estiver vazia (tamanho > 1, pois inclui '\n' ou '\0').
 * Retorna 0 se a linha estiver vazia (apenas '\n' ou '\0').
 * Baseado na função lelinha dos exemplos do repositório.
 */
int lelinha (char s[], int lim)
{
    int c, i;

    // Loop para ler caracteres até o limite, EOF, ou quebra de linha
    for(i = 0; i < lim - 1 && (c = getchar()) != '\n' && c != EOF; ++i) {
        s[i] = c;
    }

    // Se o último caractere lido foi '\n', armazena-o
    if (c == '\n') {
        s[i] = c;
        ++i;
    }

    // Termina a string com o caractere nulo
    s[i] = '\0';

    // Uma linha vazia é aquela que tem tamanho 0 (EOF) ou tamanho 1 (apenas '\n').
    // O problema diz: "só deve parar de criptografar quando for digitada uma linha vazia".
    // Se i > 1, a linha tem conteúdo além da quebra de linha.
    // Se i == 1 e s[0] == '\n', é uma linha vazia.
    // Se i == 0, é EOF ou linha realmente vazia.
    if (i == 0 || (i == 1 && s[0] == '\n')) {
        return 0; // Linha vazia
    }
    return 1; // Linha não vazia
}

/*
 * criptografa_char: Criptografa um único caractere.
 * Implementa a lógica de transposição, case-sensitivity e contagem de ocorrências.
 */
char criptografa_char(char c)
{
    int indice;
    int deslocamento;
    char base;
    char novo_char = c;

    if (isalpha(c)) {
        if (isupper(c)) {
            base = 'A';
        } else {
            base = 'a';
        }

        // 1. Determina o índice da letra no alfabeto (0 a 25)
        indice = c - base;

        // 3. Aplica a transposição
        //    O deslocamento é o valor da contagem de ocorrências da letra (0 na 1ª vez, 1 na 2ª, etc.),
        //    que é o que a descrição "incrementada de zero posições na primeira vez...
        //    de uma posição na segunda vez..." sugere para a sequência de deslocamentos.
        deslocamento = contagem_ocorrencias[indice];

        // 4. Aplica o deslocamento
        novo_char = base + (indice + deslocamento) % ALFABETO_TAM;

        // 5. Atualiza o estado:

        // a) Incrementa a contagem de ocorrências da letra (para a sub-questão 2.d)
        //    A contagem é reiniciada ao atingir 26.
        contagem_ocorrencias[indice] = (contagem_ocorrencias[indice] + 1) % ALFABETO_TAM;



    }
    // Caracteres não alfabéticos são mantidos (espaços, pontuação, etc.)
    return novo_char;
}

/*
 * criptografa_linha: Criptografa a linha de entrada e imprime o resultado.
 */
void criptografa_linha(char linha[])
{
    int i;
    for (i = 0; linha[i] != '\0'; ++i) {
        // Não criptografa a quebra de linha, se houver
        if (linha[i] != '\n') {
            putchar(criptografa_char(linha[i]));
        } else {
            putchar(linha[i]); // Imprime a quebra de linha
        }
    }
}

/*
 * Função principal do programa.
 */
int main(void)
{
    char linha[MAXLINHA];

    printf("Início da Criptografia (digite uma linha vazia para terminar):\n");

    // Loop principal para ler e criptografar múltiplas linhas
    while (lelinha(linha, MAXLINHA) != 0) {
        criptografa_linha(linha);
    }

    printf("\nCriptografia finalizada.\n");

    return 0;
}
